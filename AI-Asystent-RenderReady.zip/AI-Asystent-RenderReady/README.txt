✅ Gotowy backend do Render.com

Wgraj ten folder do GitHub (bez zmian),
a następnie utwórz Web Service na Render.com:

Build Command:     npm install
Start Command:     npm start
Environment:       OPENAI_API_KEY = <Twój klucz OpenAI>

Port: 3000 (Render wykryje automatycznie)

Po wdrożeniu otrzymasz link do backendu:
https://twoj-backend.onrender.com

W pliku frontend/script.js podmień URL zapytań na ten link.
